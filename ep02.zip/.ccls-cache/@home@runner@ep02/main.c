#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct no {
    int chave;
    int altura;
    struct no* esquerdo;
    struct no* direito;
} BST;

int maximo(int a, int b) {
    return (a > b) ? a : b;
}

BST* newno(int chave) {
    BST* aux = (BST *)malloc(sizeof(BST));

    aux->chave = chave;
    aux->direito = NULL;
    aux->esquerdo = NULL;
    aux->altura = 1;

    return aux;
}

int Altura(BST* raiz) {
    if (raiz == NULL) {
        return 0;
    }

    return raiz->altura;
}

int Fbalanceamento(BST* raiz) {
    if (raiz == NULL) {
        return 0;
    }

    return Altura(raiz->esquerdo) - Altura(raiz->direito);
}

int keySearch(BST* raiz, int chave) {

    if(raiz == NULL){
        return 0;
    }
    if (chave > raiz->chave) {
        keySearch(raiz->direito, chave);
    }
    else if (chave < raiz->chave) {
        keySearch(raiz->esquerdo, chave);
    }
    else if (raiz->chave == chave) {
        return 1;
    }
}

BST* RotR(BST* raiz) {
    BST* b = raiz->esquerdo;
    BST* t2 = b->direito;

    b->direito = raiz;
    raiz->esquerdo = t2;

  b->altura = maximo(Altura(b->esquerdo), Altura(b->direito));
    raiz->altura = maximo(Altura(raiz->esquerdo), Altura(raiz->direito));

    return b;
}

BST* RotL(BST* raiz) {
    BST* b = raiz->direito;

    BST* t1 = b->esquerdo;

    b->esquerdo = raiz;
    raiz->direito = t1;

    raiz->altura = maximo(Altura(raiz->esquerdo), Altura(raiz->direito));
    b->altura = maximo(Altura(b->esquerdo), Altura(b->direito));

    return b;
}

BST* avlInsert(BST* raiz, int chave) {
    if (raiz == NULL) {
        return newno(chave);
    }

    if (chave < raiz->chave)
    {
        raiz->esquerdo = avlInsert(raiz->esquerdo, chave);
    }
    else if (chave > raiz->chave) {
        raiz->direito = avlInsert(raiz->direito, chave);
    }
    else {
        return raiz;
    }

    raiz->altura = maximo(Altura(raiz->esquerdo), Altura(raiz->direito)) + 1;

    int fb = Fbalanceamento(raiz);

    if (fb > 1 && Fbalanceamento(raiz->esquerdo) == 1) {
        return RotR(raiz);
    }

    if (fb > 1 && Fbalanceamento(raiz->esquerdo) == -1) {
        raiz->esquerdo = RotL(raiz->esquerdo);
        return RotR(raiz);
    }

    if (fb < -1 && Fbalanceamento(raiz->direito) == -1) {
        return RotL(raiz);
    }

    if (fb < -1 && Fbalanceamento(raiz->direito) == 1) {
        raiz->direito = RotR(raiz->direito);
        return RotL(raiz);
    }

    return raiz;
}

BST* bstInsert(BST* raiz, int chave) {
    if (raiz == NULL) {
        return newno(chave);
    }
    if (chave < raiz->chave)
    {
        raiz->esquerdo = bstInsert(raiz->esquerdo, chave);
    }
    else if (chave > raiz->chave) {
        raiz->direito = bstInsert(raiz->direito, chave);
    }
    
    raiz->altura = maximo(Altura(raiz->esquerdo), Altura(raiz->direito)) + 1;

    return raiz;
}

void InOrder(BST* raiz) {
    if (raiz == NULL) {
        return;
    }

    InOrder(raiz->esquerdo);
    printf("%d\n", raiz->chave);
    InOrder(raiz->direito);
}

void PreOrder(BST* raiz) {
    if (raiz == NULL) {
        return;
    }

    printf("%d\n", raiz->chave);
    PreOrder(raiz->esquerdo);
    PreOrder(raiz->direito);
}

void PostOrder(BST* raiz) {
    if (raiz == NULL) {
        return;
    }

    PostOrder(raiz->esquerdo);
    PostOrder(raiz->direito);
    printf("%d\n", raiz->chave);
}

void generateTrees(int quantidadeAmostras, int quantidadeNos) {
    srand(time(NULL));
    clock_t inicio, fim, iniAVL, fimAVL, iniBST, fimBST;
    double tempoGeral = 0,tempoGeralTotal = 0, tempoAVL = 0, tempoAVLTotal = 0, tempoBST = 0, tempoBSTTotal = 0;

    int * alturasBST = malloc(sizeof(int) * quantidadeAmostras);
    int * alturasAVL = malloc(sizeof(int) * quantidadeAmostras);

    int mediaGeral = 0;
    int mediaBST = 0;
    int mediaAVL = 0;

  for (int i = 0; i < quantidadeAmostras; i++) {
        BST* bst = NULL;
        BST* avl = NULL;
        inicio = clock();
        for (int j = 0; j < quantidadeNos; j++) {
            int randNum = rand() % quantidadeNos + 1;
            while(keySearch(bst, randNum) != 0 && keySearch(avl, randNum) != 0){
                randNum = rand() % quantidadeNos + 1;
            }

            iniBST = clock();
            bst = bstInsert(bst, randNum);
            fimBST = clock();
            tempoBSTTotal += ((double) (fimBST - iniBST)/CLOCKS_PER_SEC);

            iniAVL = clock();
            avl = avlInsert(avl, randNum);
            fimAVL = clock();
            tempoAVLTotal += ((double) (fimAVL - iniAVL)/CLOCKS_PER_SEC);
        }
        fim = clock();
        tempoGeralTotal += ((double) (fim - inicio)/CLOCKS_PER_SEC);

        alturasAVL[i] = avl->altura;
        alturasBST[i] = bst->altura;
        free(bst);
        free(avl);
    }

    tempoGeral = tempoGeralTotal/quantidadeAmostras;
    tempoAVL = tempoAVLTotal/quantidadeAmostras;
    tempoBST = tempoBSTTotal/quantidadeAmostras;

    int totalAVL = 0;
    int totalBST = 0;

    for(int i = 0; i < quantidadeAmostras; i++){
        totalAVL += alturasAVL[i];
        totalBST += alturasBST[i];        
    }

    mediaAVL = totalAVL/quantidadeAmostras;
    mediaBST = totalBST/quantidadeAmostras;
    mediaGeral = (mediaAVL + mediaBST)/2 ;

    printf("\nExperimento com A = %d e N = %d\n", quantidadeAmostras, quantidadeNos);

    printf("----------------------------\n");
  
    printf("Altura media geral: %d\n", mediaGeral);
    printf("Tempo medio geral de construcao: %f segundo(s)\n", tempoGeral);
    printf("Tempo total geral de construcao das %d arvores: %f segundo(s)\n", quantidadeAmostras, tempoGeralTotal);

    printf("----------------------------\n");

    printf("Altura media BST comum: %d\n", mediaBST);
    printf("Tempo medio de construcao de cada BST: %f segundo(s)\n", tempoBST);
    printf("Tempo total de construcao das %d BST's: %f segundo(s)\n", quantidadeAmostras, tempoBSTTotal);

    printf("----------------------------\n");

    printf("Altura media AVL: %d\n", mediaAVL);
    printf("Tempo medio de construcao de cada AVL: %f segundo(s)\n", tempoAVL);
    printf("Tempo total de construcao das %d AVL's: %f segundo(s)\n", quantidadeAmostras, tempoAVLTotal);

    printf("----------------------------\n");

    free(alturasAVL);
    free(alturasBST);
}

void MenuSimulacao(){
    int qtdAmostras, qtdElementos;
    
    printf("Digite a quantidade de amostras:\n ");
    scanf("%d", &qtdAmostras);
    printf("Digite a quantidade de elementos para cada amostra:\n ");
    scanf("%d", &qtdElementos);

    generateTrees(qtdAmostras, qtdElementos);
}



int main(void) {

    int opt = 0;

    while(opt != 2){
        printf("Menu: (0) Nova simulacao\n");
        printf("exit: (1)\n");
        scanf("%d", &opt);

        if(opt == 0){
            MenuSimulacao();
        }
    }

    return 0;
}
